package com.rohit.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

	String jdbcURL = "jdbc:mysql://localhost:8080/rohit";
	String username = "user";
	String password = "password";

	Connection connection = null;

	public Connection fetchConnectio() {
		try {
			connection = DriverManager.getConnection(jdbcURL, username, password);
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return connection;
	}

}
