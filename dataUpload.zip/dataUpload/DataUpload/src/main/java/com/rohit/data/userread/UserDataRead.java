package com.rohit.data.userread;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.rohit.data.Company;

public class UserDataRead {

	private static List<Company> details = new ArrayList<Company>();

	public static List<Company> read(String csvFile) {
		try {
			File file = new File(csvFile);
			FileReader fr = new FileReader(file);
			String delimiter = ";";
			BufferedReader br = new BufferedReader(fr);
			String line = "";
			String[] tempArr;
			Company company = new Company();
			while ((line = br.readLine()) != null) {
				tempArr = line.split(delimiter);
				company.setName(tempArr[0]);
				company.setAddress(tempArr[1]);
				company.setZipcode(tempArr[2]);
				details.add(company);
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return details;
	}
}
