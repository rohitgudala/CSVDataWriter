package com.rohit.writedata;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.rohit.data.Company;

public class CSVWriter {

	public int writeDataintoDB(Connection conn, List<Company> details) {
		
		int result = 1;

		String sql = "insert into company (name, address, zip) values (?, ?, ?)";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			for (Company company : details) {
				ps.setString(1, company.getName());
				ps.setString(2, company.getAddress());
				ps.setString(3, company.getZipcode());
				ps.addBatch();
			}
			ps.executeBatch();
			ps.close();
			conn.close();
		} catch (SQLException e) {
			result = 0;
			e.printStackTrace();
		}

		return result;
	}
}
