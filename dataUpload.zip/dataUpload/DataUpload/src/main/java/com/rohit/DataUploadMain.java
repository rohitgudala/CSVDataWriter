package com.rohit;

import java.sql.Connection;
import java.util.List;

import com.rohit.connection.ConnectionFactory;
import com.rohit.data.Company;
import com.rohit.data.userread.UserDataRead;
import com.rohit.writedata.CSVWriter;

public class DataUploadMain {

	private static CSVWriter writer = new CSVWriter();

	public static void main(String[] args) {
		String csvFile = "C:\\Users\\Home\\codebase\\dataUpload\\DataUpload\\details.csv";
		List<Company> usercsvData = UserDataRead.read(csvFile);
		ConnectionFactory factory = new ConnectionFactory();
		Connection conn = factory.fetchConnectio();
		int result = writer.writeDataintoDB(conn, usercsvData);

		if (result > 0) {
			System.out.println("Company Data Succesfully inserted into the table");
		} else {
			System.out.println("Issue occured while data insertion .. please check the logs");
		}

	}
	
	
}
