package com.rohit;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class DataUploadMainTest {

	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void mainTest() {
		DataUploadMain dataupload = new DataUploadMain();
		dataupload.main(null);
	}
}
