package com.rohit.connection;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Test;

public class ConnectionFactoryTest {

	@Test(expected = NullPointerException.class)
	public void fetchConnectionTest() {
		ConnectionFactory cnn = new ConnectionFactory();

		Connection conn = cnn.fetchConnectio();

		try {
			assertEquals(Boolean.FALSE, conn.getAutoCommit());
			// assertEquals(,conn.get)
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
